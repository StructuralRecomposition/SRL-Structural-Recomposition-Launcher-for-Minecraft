# Third-party notices

SR Launcher bundles or invokes the following third-party components. This file
records the components actually used by the **Structural Connect** feature.

## EasyTier

- **Component:** EasyTier (`easytier-core`, `easytier-cli`)
- **Version used for development and packaging:** v2.6.4
- **Upstream:** <https://github.com/EasyTier/EasyTier>
- **License:** GNU Lesser General Public License v3.0 (LGPL-3.0)
- **License text:** [`licenses/EasyTier-LGPL-3.0.txt`](licenses/EasyTier-LGPL-3.0.txt)
- **Copyright:** EasyTier contributors

### How SR Launcher uses it

- SR Launcher starts the official **unmodified** EasyTier executables as
  separate child processes.
- SR Launcher does **not** link `easytier-core` as a Rust crate or static
  library, and does not modify the EasyTier source code.
- The executables are distributed side-by-side with the launcher in the
  application resource directory (`resources/easytier/<platform>/`).
- Because the programs are separate works, SR Launcher's own MIT-licensed code
  is not a derivative work of EasyTier. EasyTier remains under LGPL-3.0.
- Users may replace the bundled EasyTier executables with their own compatible
  builds. SR Launcher verifies the reported version (>= 2.6.4) and refuses
  older/incompatible runtimes.
- EasyTier's source code, including any modifications published by its
  authors, is available at the upstream repository above. SR Launcher does not
  hide or remove copyright notices from the binaries or license text.

### Distribution checksums (official release assets)

| Platform | Asset | SHA-256 |
|---|---|---|
| macOS x86_64 | `easytier-macos-x86_64-v2.6.4.zip` | `89fc28a6e6995259d76ce3f11775220e8a21c760e94df91a6a9db30a69b6982e` |
| macOS arm64 | `easytier-macos-aarch64-v2.6.4.zip` | `4be1882d1aa36d31c1d6ba0596f2cf8a097e371f8da124212324b2e0f8df7e4b` |
| Windows x86_64 | `easytier-windows-x86_64-v2.6.4.zip` | `27af91e270e554709b048bd32327fefd2dfce5062ae1e8701af7550c6f525f84` |
| Linux x86_64 | `easytier-linux-x86_64-v2.6.4.zip` | `61b659eaedba658fa66fe47d17e1426cdd77e5d02fa15fed447bb4357c09dfd6` |
| Linux arm64 | `easytier-linux-aarch64-v2.6.4.zip` | `f533ec25a7ea714e09f645615012200278058525795cc3bb690ff011aec1a70f` |

These are the SHA-256 digests published by the GitHub Releases API for the
v2.6.4 assets. `scripts/fetch-easytier.sh` refuses to install a file whose
digest does not match.

### EasyTier's own dependencies

EasyTier is distributed by its authors as a self-contained program. Its
transitive Rust dependencies and their licenses are documented in the upstream
repository's lockfile and release process. SR Launcher does not relicense them
and does not statically link them.

## Runtime helper library

- **x25519-dalek 2.x** — BSD-3-Clause. Used directly by SR Launcher to derive the
  public key for an EasyTier credential and for per-room host keypairs. No
  network access; it only performs local key derivation. Source:
  <https://github.com/dalek-cryptography/x25519-dalek>.

## SR Launcher dependencies

The launcher's Rust and npm dependencies are pinned in `Cargo.lock` and
`package-lock.json`. They are not vendored into this repository. License
review for those dependencies follows the existing project policy in
`research/LICENSE_AUDIT.md`.
