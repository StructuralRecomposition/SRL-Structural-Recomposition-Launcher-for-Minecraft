SRL 0.1.0 - Windows x64 portable test build

This is an unsigned cross-compiled test build. Run Install.cmd (right-click ->
Run as administrator is not required) to copy SRL to %LOCALAPPDATA%\SRL and
create Desktop/Start Menu shortcuts. Or run sr-launcher.exe directly from this
folder (keep the easytier folder next to it).

Requirements:
- Windows 10/11 x64
- Microsoft Edge WebView2 Runtime (normally included with Edge)
- No admin rights required

Structural Connect:
- The EasyTier v2.6.4 runtime for Windows is included in
  easytier\windows-x86_64\. Install.cmd copies it to %LOCALAPPDATA%\SRL\easytier.
- Do not move sr-launcher.exe away from the easytier folder if you run it
  directly; the launcher looks for easytier\<platform>\ next to the executable.

Troubleshooting "localhost refused to connect" / blank window:
1. Extract the whole ZIP to a normal folder first; do not run the EXE from
   inside the ZIP preview.
2. Install or repair the WebView2 Evergreen Runtime:
   https://developer.microsoft.com/microsoft-edge/webview2/
3. If this cloud/office PC uses a system proxy, launch from cmd with:
   set WEBVIEW2_ADDITIONAL_BROWSER_ARGUMENTS=--proxy-bypass-list=tauri.localhost;localhost;127.0.0.1
   sr-launcher.exe
4. This package is a production build (embedded UI). If you still see
   localhost:1420, you are running a development build by mistake.

This build is unsigned, so Windows SmartScreen may warn. Verify the SHA-256
next to the ZIP before running.

The package contains no settings, accounts, chat history, Java, Minecraft
instances, logs or API keys. First launch creates a clean data directory under
%APPDATA%\app.srlauncher.desktop.

Uninstall.cmd removes the program; your launcher data is intentionally kept.
