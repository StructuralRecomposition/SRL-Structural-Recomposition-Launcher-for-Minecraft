# EasyTier runtime (bundled resource)

Structural Connect starts the official EasyTier executables as separate
processes. Place the official, unmodified binaries here before packaging:

```
resources/easytier/
  macos-x86_64/{easytier-core,easytier-cli}
  macos-aarch64/{easytier-core,easytier-cli}
  windows-x86_64/{easytier-core.exe,easytier-cli.exe}
  linux-x86_64/{easytier-core,easytier-cli}
  linux-aarch64/{easytier-core,easytier-cli}
```

Use `scripts/fetch-easytier.sh` (downloads v2.6.4, verifies SHA-256) or copy
the official release manually. At runtime the launcher also accepts:

- `SRL_EASYTIER_CORE` + `SRL_EASYTIER_CLI` (development/test override)
- `$APP_DATA/connect/runtime/`

EasyTier is LGPL-3.0. See `THIRD_PARTY_NOTICES.md` and
`licenses/EasyTier-LGPL-3.0.txt`.
